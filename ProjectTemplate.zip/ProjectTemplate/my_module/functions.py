"""A collection of function for doing my project."""


"""This function creates the list for each set of ingredients before putting it into the

larger ingredient_array

----

Parameters

size = how much of the ingredient. Ex: 2.0

ingredient = what the ingredient is. Ex: 'cups of flour'

Returns an array (list of lists)"""
    

def ingredient_sorter(size, ingredient, ingredient_array):
    
    ingredient_list = [size, ingredient]
    
    ingredient_array.append(ingredient_list)
    
    return ingredient_array



"""This is just a simple function to create the ratio that will
be multiplied by the 0th index of every smaller list within the 
larger array
----
Parameters: 
servings_out and servings_in are both floats

Returns: float"""


def servings_ratio_creator(servings_out, servings_in):
    
    servings_ratio = servings_out/servings_in
    
    return servings_ratio





"""This function is now meant to take the 0th index of each list within the master list

ingredient_array and scale it either up or down depending on what the value of

servings_ratio is.

----

Parameters: an array is taken as input

Returns the updated scaled up or scaled down array"""

    
def list_multiplier(array, servings_ratio):
    
    for list_in_array in array:
        
        # We are not just multiplying the ingredients by the servings_out_new value
        # it is the ratio between both of them
        # using the function created above
        
        list_in_array[0] = list_in_array[0] * servings_ratio    
            
    print(array)
