"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

import functions as fn

##
##

## This is where all the test functions are held



def test_ingredient_sorter():
    
    ingredient_list_test = [[1,'cup of flour'], [.5, 'cups of sugar'], [0.25, 'cups of butter']]
    
    assert callable(fn.ingredient_sorter)
    assert isinstance(fn.ingredient_sorter(1, 'cups of flour',[]), list)
    assert isinstance(fn.ingredient_sorter(2, 'cups of sugar',[]), list)
    assert isinstance(fn.ingredient_sorter(ingredient_list_test[0], ingredient_list_test[2], []), list)
    assert len(ingredient_list_test) == 3
    
test_ingredient_sorter()

    

def test_servings_ratio_creator():
    
    assert callable(fn.servings_ratio_creator)
    assert isinstance(fn.servings_ratio_creator(4,2), float)
    assert isinstance(fn.servings_ratio_creator(4.0,2.0), float)
    assert fn.servings_ratio_creator(10.0, 2.5) == 4.0
    assert fn.servings_ratio_creator(10.0, 5.0) == 2.0
    
test_servings_ratio_creator()